#ifndef boolean_H
#define boolean_H
/*Deskripsi : boolean*/
/* NIM/Nama  : 24060124140124/Aqiatilllah Rezi Zhafran*/
/* Tanggal   : 11 September 2024*/
#define true 1
#define false 0
#define boolean unsigned char
#endif